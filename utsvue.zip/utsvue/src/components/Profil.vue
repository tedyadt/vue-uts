<template>
  <div>
    <h1>Halaman Profil</h1>
    <h2>Profilll su</h2>
  </div>
</template>

<script>
export default {
  beforeRouteEnter(to, from, next) {
    to.meta.hideMainContent = true;
    next();
  },
  beforeRouteLeave(to, from, next) {
    to.meta.hideMainContent = false;
    next();
  },
  // ...
}
</script>
